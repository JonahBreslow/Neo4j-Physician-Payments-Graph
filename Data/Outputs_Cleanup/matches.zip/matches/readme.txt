If you guys want to run the dedupe yourself use the files:
	physicians_info_dedup.csv and prescriber_dedup.csv

Put it in the path: "/data/Outputs_Cleanup/..."

The file matches.csv contains the matches
to map it back to the original node id
use the files:
	sunshineNewID.csv and partDNewID.csv

I also made two files to show you guys what didnt match. 
There are some matches in there I know of 1 edge case where its the same guy, same specialty but different city.
I included it incase you guys wanted to try to do better.